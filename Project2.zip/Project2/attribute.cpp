#include<iostream>
#include"attribute.h"
using namespace std;

Attribute::Attribute() {

}