#include<iostream>
#include"monster.h"
using namespace std;

Monster::Monster() {

}