#include<iostream>
#include"character.h"
using namespace std;

Character::Character(){

}