#include<iostream>
#include"weapon_and_equipment.h"
using namespace std;

WeaponAndEquipment::WeaponAndEquipment() {

}